package br.com.biogranja.model;
public class Cliente {
    
}
